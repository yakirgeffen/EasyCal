/* EasyCal – minimal vanilla JS */
document.addEventListener('DOMContentLoaded', () => {

  /* shorthand */
  const $ = id => document.getElementById(id);

  /* refs */
  const eventTitle=$('eventTitle'),startDate=$('startDate'),startTime=$('startTime'),
        endDate=$('endDate'),endTime=$('endTime'),timezone=$('timezone'),
        locationInp=$('location'),desc=$('description'),descCounter=$('descCounter'),
        buttonText=$('buttonText'),showIcon=$('showIcon'),
        colorOpts=document.querySelectorAll('input[name="colorScheme"]'),
        previewTitle=$('previewTitle'),previewDateTime=$('previewDateTime'),
        previewLocation=$('previewLocation'),previewButton=$('previewButton'),
        previewBtnText=$('previewButtonText'),previewIcon=$('previewIcon'),
        previewDescription=$('previewDescription'),
        snippetCode=$('snippetCode'),copyBtnButton=$('copyBtnButton'),
        copyBtnFull=$('copyBtnFull'),toast=$('copySuccess');

  /* === time-picker bootstrap === */
  (()=>{        /* populate selects & sync hidden time inputs */
    const hSel=[startHour,endHour],mSel=[startMinute,endMinute];
    for(let h=1;h<=12;h++){const l=h.toString().padStart(2,'0');hSel.forEach(s=>s.add(new Option(l,l)));}
    for(let m=0;m<60;m+=5){const l=m.toString().padStart(2,'0');mSel.forEach(s=>s.add(new Option(l,l)));}
    function sync(w){
      const hh=$(w+'Hour').value||'12';
      const mm=$(w+'Minute').value||'00';
      const pp=$(w+'Period').value||'AM';
      const h24=(parseInt(hh)%12)+(pp==='PM'?12:0);
      $(w+'Time').value=h24.toString().padStart(2,'0')+':'+mm;
    }
    ['start','end'].forEach(w=>['Hour','Minute','Period'].forEach(p=>$(w+p).addEventListener('change',()=>sync(w))));

    /* default start = now+30 min, snap to :00/:30 */
    const now=new Date();now.setMinutes(now.getMinutes()+30-now.getMinutes()%30,0,0);
    const [Y,M,D]=[now.getFullYear(),now.getMonth()+1,now.getDate()].map(n=>String(n).padStart(2,'0'));
    startDate.value=endDate.value=`${Y}-${M}-${D}`;
    const to12   = dt => [(((dt.getHours()+11)%12)+1).toString().padStart(2,'0'),
                          dt.getMinutes().toString().padStart(2,'0'),
                          dt.getHours()<12?'AM':'PM'];
    const [h,m,ampm]=to12(now);
    [startHour.value,startMinute.value,startPeriod.value]=[h,m,ampm];
    const end=new Date(now);end.setHours(end.getHours()+1);
    const [eh,em,eampm]=to12(end);
    [endHour.value,endMinute.value,endPeriod.value]=[eh,em,eampm];
    sync('start');sync('end');
  })();

  /* char counter */
  desc.addEventListener('input',()=>{
    const used=desc.value.length;
    descCounter.textContent=`${used} / 400`;
    descCounter.classList.toggle('text-error',used>380);
  });

  /* colour preview on label hover */
  document.querySelectorAll('input[name="colorScheme"]').forEach(inp=>{
    const cls=`cal-btn-${inp.value}`;
    inp.nextElementSibling.addEventListener('mouseenter',()=>previewButton.classList.add(cls));
    inp.nextElementSibling.addEventListener('mouseleave',updateButtonStyle);
  });

  /* live update */
  document.getElementById('eventForm').addEventListener('input',()=>{
    updatePreview();generateSnippet();
  });

  /* ============== preview functions ============== */
  function updatePreview(){
    previewTitle.textContent   = eventTitle.value  || 'Event title';
    previewLocation.textContent= locationInp.value || 'Location';
    previewDateTime.textContent= formatForPreview(startDate.value,startTime.value,timezone.value);

    if(desc.value.trim()){
      previewDescription.textContent = desc.value.trim();
      previewDescription.classList.remove('hidden');
    }else{
      previewDescription.classList.add('hidden');
    }

    previewBtnText.textContent = buttonText.value  || 'Add to Calendar';
    previewIcon.style.display  = showIcon.checked ? 'inline-flex' : 'none';
    updateButtonStyle();
  }
  function updateButtonStyle(){
    previewButton.classList.remove('cal-btn-light','cal-btn-dark','cal-btn-purple');
    const picked=[...colorOpts].find(o=>o.checked)||{value:'dark'};
    previewButton.classList.add('cal-btn-'+picked.value);
  }
  function formatForPreview(d,t,tz){
    if(!d||!t) return '–';
    const [Y,M,D]=d.split('-').map(Number);const [h,m]=t.split(':').map(Number);
    return new Date(Date.UTC(Y,M-1,D,h,m)).toLocaleString('en-US',{
      year:'numeric',month:'long',day:'numeric',
      hour:'numeric',minute:'2-digit',timeZone:tz});
  }

  /* ============== snippet generation ============== */
  let buttonSnippet='',fullSnippet='';
  function generateSnippet(){
    /* button label & inline style */
    const label  = buttonText.value || 'Add to Calendar';
    const colour = ([...colorOpts].find(o=>o.checked)||{value:'dark'}).value;
    const btnStyles={
      light : 'background:#FFFFFF;color:#241C15;border:1px solid #DADADA;',
      dark  : 'background:#241C15;color:#FFFFFF;border:none;',
      purple: 'background:#FFE01B;color:#241C15;border:none;'
    } + 'padding:10px 16px;border-radius:6px;font:15px/1.3 Inter, sans-serif;text-decoration:none;display:inline-flex;align-items:center;';
    const iconHTML = showIcon.checked ? '📅 ' : '';

    /* Google link only (demo) */
    const enc=s=>encodeURIComponent(s);
    const s=`${startDate.value}T${startTime.value}`.replace(/[-:]/g,'').slice(0,15)+'Z';
    const e=`${endDate.value}T${endTime.value}`.replace(/[-:]/g,'').slice(0,15)+'Z';
    const url=`https://calendar.google.com/calendar/render?action=TEMPLATE&text=${enc(eventTitle.value||'Event')}&dates=${s}/${e}&details=${enc(desc.value||'')}&location=${enc(locationInp.value||'')}&ctz=${enc(timezone.value)}`;

    /* snippets */
    buttonSnippet=`<a href="${url}" style="${btnStyles[colour]}">${iconHTML}${label}</a>`;
    fullSnippet=`<!-- EasyCal - https://easycal.app -->\n<div style="display:inline-block;position:relative;">\n  ${buttonSnippet}\n  <!-- provider dropdown here -->\n</div>`;
    snippetCode.textContent=fullSnippet;
  }

  /* copy helpers + toast */
  function showToast(){
    toast.classList.add('show');
    setTimeout(()=>toast.classList.remove('show'),2500);
  }
  async function copy(text){await navigator.clipboard.writeText(text).catch(()=>{});showToast();}
  copyBtnButton.onclick=()=>copy(buttonSnippet);
  copyBtnFull  .onclick=()=>copy(fullSnippet);

  /* first render */
  updatePreview();generateSnippet();
});
/* EasyCal – minimal vanilla JS */
